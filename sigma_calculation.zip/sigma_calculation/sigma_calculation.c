#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
int a, b, ans;
char Ca[50];
char Cb[50];
int sigma(int Pmin, int Pmax)
{
    int min = Pmin;
    int max = Pmax;
    if(Pmin > Pmax){
        max = Pmin;
        min = Pmax;
    }
    return ((max + min) * (max - min + 1) / 2);
}
int analysis(char *str)
{
    while (*str)
    {
        if (!isdigit(*str))
        {
            return 0;
            break;
        }
        str++;
    }
    return 1;
}
void processing(int num ,char *C){
    while (1){
        printf("%d回目 入力:",num);
        scanf("%49s", C);
        if (!strcmp(C,"end")){
            printf("enterを押して終了...");
            while (getchar() != '\n');
            getchar();
            exit(0);
            break;
        }
        if (analysis(C)){
            break;
        }
        printf("無効な値です\n");
        while (getchar() != '\n');
    }
}
int main(void)
{
    printf("整数を2回入力してください。\n");
    printf("簡易シグマ計算で、1回目に入力した数値から2回目に入力した数値までの合計を出します。\n");
    printf("[end]と入力すると終了します。\n");
    printf("例:\n");
    printf("入力: 1,3\n");
    printf("出力: answer: 6\n");
    printf("（1 + 2 + 3 = 6）\n");
    while (1){
        processing(1,Ca);
        processing(2,Cb);
        a = atoi(Ca);
        b = atoi(Cb);
        ans = sigma(a, b);
        printf("answer:%d~%dまでをすべて足した数:%d\n", a, b, ans);
    }
    return 0;
}